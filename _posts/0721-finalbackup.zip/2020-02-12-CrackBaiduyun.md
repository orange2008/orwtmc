---
title: Download BaiduYun Without Any Speed Limit
published: true
---
# At first
**If you are in China, you must have used Baidu Web Disk, and if you do not open the membership is very slow, only a few KB per second. So today I ’m going to teach everyone to download without speed limit.**

# Before
Before this, you should go and see our another topic [Portal](Aria2Tools).
Download Aria2Tools, you can find the download link in another topic.
A Windows PC.
Internet Connection.
Baiduyun account and the file(s) you wanted to download.

# Operation

## Step 1
Download the customize chrome browser, [Download here](http://www.mediafire.com/file/b7mlapm46usc4ee/Chrome_%25E6%2587%2592%25E4%25BA%25BA%25E7%2589%2588_x86_64.7z/file)

## Step 2
When you downloaded the file, extract to a folder.
![](https://cdn.jsdelivr.net/gh/orange2008/IMGBED/assets/20200708123942.png)

## Step 3
Run chrome.exe

## Step 4
If you see this prompt, click enable.
![](https://cdn.jsdelivr.net/gh/orange2008/IMGBED/assets/20200708124031.png)

## Step 5
Go to [https://pan.baidu.com](https://pan.baidu.com). And login your account.

## Step 6
![](https://cdn.jsdelivr.net/gh/orange2008/IMGBED/assets/20200708124110.png)
If you see this thing, please scan this QR code using WeChat, and get the code. If you don't have any WeChat account, you can just click "确定", it will crash, then you can skip it.

## Step 7
Now we can download files now.
Select the file(s) you need to download (DON'T SELECT FOLDER!!!)
![](https://cdn.jsdelivr.net/gh/orange2008/IMGBED/assets/20200708124159.png)
![](https://cdn.jsdelivr.net/gh/orange2008/IMGBED/assets/20200708124534.png)

Before click this button, make sure your aria2tools server is online.

## Step 8
Please allow the permission.
Click "Always Allow"

## Step 9
Then you can open the aria2tools console.
The speed will over the sky!!!
If the speed still on several kilobyte per second, make sure you are not banned, if you have been banned, the account will be unban under 7 days.

# End
Thanks for seeing! Hope I can help you!